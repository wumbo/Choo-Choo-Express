//
//  Keyboard.h
//  Choo Choo Express
//
//  Created by Simon Crequer on 22/03/15.
//  Copyright (c) 2015 Simon Crequer. All rights reserved.
//

#ifndef __Choo_Choo_Express__Keyboard__
#define __Choo_Choo_Express__Keyboard__

#include <stdio.h>

void keyboard(unsigned char key, int x, int y);
void special(int key, int x, int y);

#endif /* defined(__Choo_Choo_Express__Keyboard__) */
