//
//  Car.h
//  Choo Choo Express
//
//  Created by Simon Crequer on 2/04/15.
//  Copyright (c) 2015 Simon Crequer. All rights reserved.
//

#ifndef __Choo_Choo_Express__Car__
#define __Choo_Choo_Express__Car__

#include <stdio.h>

class Car
{
private:

public:
    int dist;
    void draw();
    Car(int dist);
};

#endif /* defined(__Choo_Choo_Express__Car__) */
