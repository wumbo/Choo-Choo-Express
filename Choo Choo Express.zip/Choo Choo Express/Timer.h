//
//  Timer.h
//  Choo Choo Express
//
//  Created by Simon Crequer on 2/04/15.
//  Copyright (c) 2015 Simon Crequer. All rights reserved.
//

#ifndef __Choo_Choo_Express__Timer__
#define __Choo_Choo_Express__Timer__

#include <stdio.h>

void trainTimer(int value);
void carTimer(int value);
void personTimer(int value);

#endif /* defined(__Choo_Choo_Express__Timer__) */
