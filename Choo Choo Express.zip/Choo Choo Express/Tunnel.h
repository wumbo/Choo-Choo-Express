//
//  Tunnel.h
//  Choo Choo Express
//
//  Created by Simon Crequer on 2/04/15.
//  Copyright (c) 2015 Simon Crequer. All rights reserved.
//

#ifndef __Choo_Choo_Express__Tunnel__
#define __Choo_Choo_Express__Tunnel__

#include <GL/freeglut.h>

class Tunnel
{
private:
    
public:
    void draw();
};

#include <stdio.h>

#endif /* defined(__Choo_Choo_Express__Tunnel__) */